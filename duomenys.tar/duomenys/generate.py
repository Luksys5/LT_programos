fh=open('Lentele.txt','r')
lines=fh.readlines()
def search(strang):
	z=0
	name=''
	for x in lines:
		cols=x.split()
		if cols[0] == strang:
			if cols[1] != '1ud9_D':
				name=strang
				z=vidurkis(cols)
	if z == 0:
		print 'nera:'+strang
		return ('end',0)
	return(name,z)
def vidurkis(scores):
	scores=scores[1:196]
	Suma=0
	kiek=0
	for x in scores:
		Suma+=float(x)
		kiek+=1	
	Vid=Suma/kiek
	return Vid
def put():
	string='';
	Matr={}
	maxscore=0
	zname='end'
	print 'write end to stop'
	while string != 'end':
		string = raw_input("Enter first family members:")
		if string != 'end':
			(name,score)=search(string)
			if name != 'end':
				Matr[name] = score
			print name+' '+str(score)
			if score>maxscore:
				maxscore=score
				zname=name
	return (zname,maxscore,Matr)
def atrenka():
	(name,score,MATRIX)=put()
	if name != 'end' :
		firstfile = raw_input("ENTER filename:")
		fd=open(firstfile,'w')
		fd.write('pirmos grupes atstovas:'+name+' '+str(score)+'\n')
		for key, value in MATRIX.iteritems():
			fd.write(key+' '+str(value)+'\n')
	return
def iraso():
	string=raw_input("grupiu sk: ")
	out=raw_input("output failo pavadinimas: ")
	fd=open(out,'w')
	fd1=open(out+'.pdb','w')
	for x in xrange(1, int(string)+1):
		fh=open(str(x),'r')
		fm=open(str(x)+'alt','w')
		line=fh.readline()
		line = line.split(':')	
		fd.write(line[1])
		line=line[1].split()
		fd1.write(line[0]+'.pdb\n')
		lines = fh.readlines()
		#fm.write(line[0]+'.pdb\n')
		for y in lines:
			temp=y.split()
			if line[0] !=temp[0]: 
				fm.write(temp[0]+'.pdb\n')
		
string=raw_input("irasyti grupes 1, atstovu grupavimas 2:")
if string == '1':
	atrenka()
elif string == '2':
	iraso()	
